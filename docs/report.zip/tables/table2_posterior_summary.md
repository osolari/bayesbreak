| Quantity | Value |
|---|---:|
| Displayed segmentation $\hat{k}_{MAP}$ | 4 |
| Posterior mean $E[k\mid y]$ | 4.742 |
| MAP segment count $\arg\max_k P(k\mid y)$ | 4 |
| Posterior probability of displayed MAP segmentation $q(\hat t)$ | 0.284 |
| log $p(y)$ | -18.031 |
